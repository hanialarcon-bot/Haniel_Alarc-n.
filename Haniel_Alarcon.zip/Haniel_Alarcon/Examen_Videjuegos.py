
#===========================MENU Y OPCION============================
def mostrar_menu():
    print("""
    ========== MENÚ PRINCIPAL ==========
    1. Stock por plataforma
    2. Búsqueda de juegos por rango de precio
    3. Actualizar precio de juego
    4. Agregar juego
    5. Eliminar juego
    6. Salir
    =====================================
    """)

def seleccion_opcine():
    try:
        opcion=int(input("Ingrese una de las opciones: "))
        if opcion>=1 and opcion <=6:
            return opcion
        else:
            return False
    except:
        return False
    
#=========================OPCION 1 =====================================
def stock_plataforma(plataforma, diccionario_juegos, diccionario_inventario):
    acumular_stock=0
    for clave_juegos, valor_juegos in diccionario_juegos.items():
        if valor_juegos[1].lower()==plataforma:

            for clave_inventario, valor_invetario in diccionario_inventario.items():

                if clave_juegos==clave_inventario:
                    acumular_stock+=valor_invetario[1]
    print("Hay un total de: ", acumular_stock, "Stock.")
#================================ OPCION 2 ===================================

def busqueda_precio(p_min, p_max, diccionario_juegos, diccionario_inventario):
    lista_Stock=[]
    for clave_inventario, valor_inventario in diccionario_inventario.items():
        if valor_inventario[0] >= p_min and valor_inventario[0] <= p_max and valor_inventario[1]>0:

            for clave_juegos, valor_juegos in diccionario_juegos.items():
                if clave_inventario==clave_juegos:
                    lista_Stock.append(f"{valor_juegos[0]} -- {clave_inventario}")
                    break

    if len(lista_Stock)==0:
        print("No hay juegos en ese rango de precios.")
    else:
        lista_Stock.sort()

        for ordenado in lista_Stock:
            print(ordenado)
#======================================== OPCION 3 =========================================
def buscar_codigo(codigo, dicconario_juegos):
    for codigo_juegos in dicconario_juegos.keys():
        if codigo_juegos == codigo:
            return True
    return False

def actualizar_precio(codigo, nuevo_precio,diccionario_juegos, diccionario_inventario):
    if buscar_codigo(codigo, diccionario_juegos) == True:
        valor_inventario=diccionario_inventario[codigo]
        valor_inventario[1]=nuevo_precio
        return True
    else:
        return False
#========================= OPCION 4 ====================================
def codigo_sin_espacios(codigo, diccionario_juegos):
    codigo=codigo.upper().strip()
    for clave_juego in diccionario_juegos.keys():
        if clave_juego==codigo or codigo=="":
            return False
        else:
            return True
def titulo_sin_espacios(titulo):
    if titulo.strip()=="":
        return False
    else:
        return True
def plataforma_sin_espacios(plataforma):
    if plataforma.strip()=="":
        return False
    else:
        return True
def genero_sin_espacios(genero):
    if genero.strip()=="":
        return False
    else:
        return True
def asignar_clasificacion(clasificacion):
    clasificacion=clasificacion.upper()
    if clasificacion=="E" or clasificacion=="T" or clasificacion=="M":
        return True
    else:
        return False
def almacenar_multiplayer(multiplayer):
    multiplayer=multiplayer.lower()
    if multiplayer=="s":
        return True
    elif multiplayer=="n":
        return False
def editor_sin_espacios(editor):
    if editor.strip()=="":
        return False
    else:
        return True
def precio_mayor(precio):
    try:
        precio=int(precio)
        if precio>=0:
            return True
        else:
            return False
    except:
        return False
def stock_mayor(stock):
    try:
        stock=int(stock)
        if stock>=0:
            return True
        else:
            return False
    except:
        return False
def agregar_juego(codigo, titulo, plataforma, genero, clasificacion, multiplayer, editor, precio, stock, diccionario_juegos, diccionario_inventario):
    for clave_juego in diccionario_juegos.keys():
        if clave_juego==codigo:
            return False
        else:
            diccionario_juegos.update({codigo:[titulo, plataforma, genero, clasificacion, multiplayer, editor]})
            diccionario_inventario.update({codigo:[precio, stock]})
            return True

#============================ OPCION 5 ======================================
def eliminar_juego(codigo, diccionario_juegos, diccionario_inventario):
        if buscar_codigo(codigo, diccionario_juegos)==True:
            del diccionario_inventario[codigo]
            del diccionario_juegos[codigo]
            return True
        else:
            return False
            

#========================= CODIGO PRINCIPAL ======================
juegos = {
    'G001': ['Eclipse Runner', 'PC', 'accion', 'T', True,'NovaStudio'],
    'G002': ['Puzzle Atlas', 'Switch', 'puzzle', 'E', False,'BrightWorks'],
    'G003': ['Sky Legends', 'PS5', 'aventura', 'T', True,'OrionGames'],
    'G004': ['Racing Pulse', 'PC', 'carreras', 'E', True,'VelocityLab'],
    'G005': ['Mystic Farm', 'Switch', 'simulacion', 'E', False,'GreenSeed'],
    'G006': ['Shadow Tactics', 'Xbox', 'estrategia', 'M', False,'IronGate'],
    }

inventario = {
    'G001': [9990, 7],
    'G002': [19990, 0],
    'G003': [42990, 3],
    'G004': [14990, 5],
    'G005': [17990, 9],
    'G006': [39990, 2],
    }

while True:
    mostrar_menu()
    opcion_verificada=seleccion_opcine()
    match opcion_verificada:
        case 1:
            nombre_plataforma=input("Ingresa el nombre de la plataforma: ").lower()
            stock_plataforma(nombre_plataforma, juegos, inventario)
        case 2:
            while True:
                try:
                    precio_minimo=int(input("Ingresa el precio minimo: "))
                    precio_maximo=int(input("Ingrese el precio maximo: "))
                    if precio_minimo>=0 and precio_maximo>=0 and precio_maximo<=precio_maximo:
                        busqueda_precio(precio_minimo, precio_maximo, juegos, inventario)
                        break
                    else:
                        print("=========================CONDICIONES=============================")
                        print(" ~ Los valores deben ser mayores o iguales a \"0\"")
                        print(" ~ El precio minimo debe ser menor o igual al precio maximo")

                except ValueError:
                    print("Debe ingresar valores enteros")
        case 3:
            while True:
                print("===========Modifiquemos un precios==========")
                codigo=input("Ingresa el codigo: ").upper()
                while True:
                    try:
                        precio_asignar=int(input("Ingrese el precio para modificar: "))
                        if precio_asignar>0:
                            break
                        else:
                            print("Debe ser mayo a \"0\". Intente de nuevo")
                    except ValueError:
                        print("Debe ser un valor entero positivo. Inteste de nuevo")
                actualizar=actualizar_precio(codigo, precio_asignar,juegos, inventario)
                if actualizar==True:
                    print("Precio actualizado")
                else:
                    print("El código no existe")
                otro_precio=input("¿Desea modeficar otro precio \"s\" o \"n\"?: ").lower()

                if otro_precio=="s":
                    continue
                elif otro_precio=="n":
                    break
        case 4:
            codigo_nuevo=input("Ingresa un codigo: ")
            titulo_nuevo=input("Ingresa el Titulo: ")
            plataforma=input("Ingresa la platefor que pertenese el juego: ")
            genero=input("¿Que genero es?: ")
            clasificacion=input("¿Que clasificacion es \"E\", \"T\" o \"M\"?: ")
            multiplayer=input("¿Que Multiplaye es \"s\" o \"n\"?")
            editor_nuevo=input("Ingresa el editor: ")
            precio_nuevo=input("Ingresa el precio: ")
            stock_nuevo=input("Ingresa un Stock: ")
            
            validar_codigo=codigo_sin_espacios(codigo_nuevo, juegos)
            validar_titulo=titulo_sin_espacios(titulo_nuevo)
            validar_plataforma=plataforma_sin_espacios(plataforma)
            validar_genero=genero_sin_espacios(genero)
            validar_clasificacion=asignar_clasificacion(clasificacion)
            validar_multiplayer=almacenar_multiplayer(multiplayer)
            validar_editor=editor_sin_espacios(editor_nuevo)
            validar_precio=precio_mayor(precio_nuevo)
            validar_stock=stock_mayor(stock_nuevo)

            if validar_codigo==True and validar_titulo==True and validar_plataforma==True and validar_genero==True and validar_clasificacion== True and validar_precio==True and validar_stock==True:
                agregar_aseptada=agregar_juego(codigo_nuevo, titulo_nuevo, plataforma, genero, clasificacion, multiplayer, editor_nuevo, precio_nuevo, stock_nuevo, juegos, inventario)
                if agregar_aseptada==True:
                    print("Juego agregado")
                else:
                    print("El código ya existe")
            else:print("""
                ============================== CODICIONES PARA AGREGAR =============================
                Codigo: No vacío ni solo espacios en blanco, y que no exista ya en losdiccionarios. 
                Titulo: No vacío ni solo espacios en blanco.
                Plataforma: No vacío ni solo espacios en blanco.
                Genero: No vacío ni solo espacios en blanco.
                Clasificacion: Debe ser exactamente 'E', 'T' o 'M'.
                Multiplayer: El usuario ingresa 's' o 'n'.
                Editor: No vacío ni solo espacios en blanco.
                Precio: Número entero mayor que cero.
                Stock: Número entero mayor que cero.
                    """)

        case 5:
            eliminar_codigo=input("Ingresa el codigo para eliminar: ").upper()
            validar_eliminacion=eliminar_juego(eliminar_codigo, juegos, inventario)

            if validar_eliminacion==True:
                print("Juego eliminado si fue exitoso")
            else:
                print("El código no existe")



        case 6:
            print("Programa finalizado.")
            break
